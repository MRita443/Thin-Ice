# -*- coding: utf-8 -*-
"""
Created on Tue Dec 14 18:28:37 2021

@author: rital
"""

import pygame

from pygame.locals import (
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_SPACE,
    K_ESCAPE,
    KEYDOWN,
    QUIT,
)

def spaces_number():
    spaces = 0
    for row in range(0, len(levels[current_level])):
        for element in levels[current_level][row]:
            if element == "-" or element == "L" or element == "K" or element == "F" or element == "D":
                spaces += 1
    return spaces
    

pygame.init()

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT, ))
pygame.display.set_caption("Thin Ice")



'''
Legend 
    0: Empty space
    1: External barrier
    -: Walkable space
    F: Final block of the level
    D: Double block, can be stepped on twice before sinking
    K: Key block
    L: Locked block, requires a key to go through
'''
   
levels = [
    ["0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "1111111111111111111111111",
    "1----------------------F1",
    "1111111111111111111111111",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000"],
    
    ["0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000001111000000000000000",
    "1111111--1111111111111111",
    "1---------------------F11",
    "1111----------------11111",
    "0001111111111111111110000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000"],
    #Fazer um nível em forma de chave!!
    #Fazer um nível a spawnar na direita
    ["0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000001111111110000000000",
    "0000001------K10000000000",
    "0000001-------10000000000",
    "0000001--1111110000000000",
    "1111111--1111111000000000",
    "1--------------1000000000",
    "1111-----------1000000000",
    "0001111--1111111111111100",
    "0000001----------L----100",
    "00000011--------11111-100",
    "000000011111111110001F100",
    "0000000000000000000011100",
    "0000000000000000000000000",
    "0000000000000000000000000"],
    
    ["0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "1111111111111110000000000",
    "1------------K10000000000",
    "1-------------10000000000",
    "1------111111110000000000",
    "1--D---111111111000000000",
    "1--------------1000000000",
    "1--------------1000000000",
    "1--L----11111111111111111",
    "1-----------------------1",
    "1-----------------------1",
    "1---111111111111111111111",
    "1---100000000000000000000",
    "1F11100000000000000000000",
    "1110000000000000000000000"],
    
    ["0000000000000000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000",
    "0000000011111000000000000",
    "00000111-----100000000000",
    "000011--------10000000000",
    "00011---------10000000000",
    "0011---------100000000000",
    "011---------1000000000000",
    "1---------KF1000000000000",
    "011---------1000000000000",
    "0011---------100000000000",
    "00011---------10000000000",
    "000011--------10000000000",
    "00000111-----100000000000",
    "0000000011111000000000000",
    "0000000000000000000000000",
    "0000000000000000000000000"]
]

puffle_img = pygame.image.load('Puffle__.png')
block_img = pygame.image.load('Bloco.png')
finalblock_img = pygame.image.load('Bloco final.png')
lockblock_img = pygame.image.load('Bloco unlockable.png')
doubleblock_img = pygame.image.load('Bloco duplo.png')
key_img = pygame.image.load('Key.png')

clock = pygame.time.Clock()

current_level = 0
solved = 0
points = 0
starting_positions = [(32, 288), (32, 288), (32, 288), (32, 288), (32, 288)]
spaces_num = spaces_number()
key_block = ()
final_block = ()
locked_block = ()
double_block = ()
barriers = set()
used = set()
key = False
first_pass = False
left_key = False
right_key = False
up_key = False
down_key = False


puffle_x = starting_positions[current_level][0]      
puffle_y = starting_positions[current_level][1]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             

block_size = 32

left_key = right_key = up_key = down_key = False
game_over_check = False
time_since_last_movement = 0
running = True



while running:
    
    dt = clock.tick(60)
    previous_position = (puffle_x, puffle_y, )
    
    #Drawing

    ##Screen
    screen.fill((155, 205, 255))
    
    ##Fonts
    game_over_font = pygame.font.Font("AlegreyaSans-Black.ttf", 72, bold=True, italic=False)
    game_over_text_font = pygame.font.Font("AlegreyaSans-Black.ttf", 32, bold=False, italic=False)
    main_menu_font = pygame.font.Font("AlegreyaSans-Black.ttf", 28, bold=True, italic=False)
    
    game_over = game_over_font.render('Game Over', True, (255, 255, 255))
    game_over_text = game_over_text_font.render('Your puffle drowned. Press SPACE to replay this level!', True, (155, 205, 255))
    level_num = main_menu_font.render('LEVEL ' + str(current_level + 1), True, (0, 79, 156))
    square_count = main_menu_font.render(str(len(used)) + "/" + str(spaces_num), True, (0, 79, 156))
    solved_count = main_menu_font.render("SOLVED " + str(solved), True, (0, 79, 156))
    points_count = main_menu_font.render("POINTS " + str(points), True, (0, 79, 156))

    
    ##Menu
    pygame.draw.rect(screen, (215, 240, 255), (0, 0, SCREEN_WIDTH, 48))
    pygame.draw.rect(screen, (215, 240, 255), (0, 552, SCREEN_WIDTH, 48))
    screen.blit(level_num, (8, 10))
    screen.blit(square_count, (375, 10))
    screen.blit(solved_count, (672, 10))
    screen.blit(points_count, (640, 560))
    
    ##Level
    for row in range(0, len(levels[current_level])):
        for col in range(0, len(levels[current_level][0])):
            
            if (col*block_size, row*block_size, ) in used and (col*block_size, row*block_size, ) != (puffle_x, puffle_y, ):
                #Mark the block where the puffle is as dark blue
                pygame.draw.rect(screen, (0, 0, 255), (col*block_size, row*block_size, block_size, block_size)) 
                
            elif levels[current_level][row][col] == '1':
                screen.blit(block_img, (col*block_size, row*block_size, block_size, block_size) )
                barriers.add((col*block_size, row*block_size,))
                
            elif levels[current_level][row][col] == '-':
                pygame.draw.rect(screen, (217, 241, 255), (col*block_size, row*block_size, block_size, block_size)) 
                
            elif levels[current_level][row][col] == 'F':
                screen.blit(finalblock_img, (col*block_size, row*block_size, block_size, block_size) )
                final_block = (col*block_size, row*block_size, )
                
            elif levels[current_level][row][col] == 'K':
                pygame.draw.rect(screen, (217, 241, 255), (col*block_size, row*block_size, block_size, block_size))
                screen.blit(key_img, (col*block_size, row*block_size, block_size, block_size) )
                key_block = (col*block_size, row*block_size, )
                
            elif levels[current_level][row][col] == 'L':
                screen.blit(lockblock_img, (col*block_size, row*block_size, block_size, block_size) )
                locked_block = (col*block_size, row*block_size, )
                
            elif levels[current_level][row][col] == 'D':
                if not first_pass:
                    screen.blit(doubleblock_img, (col*block_size, row*block_size, block_size, block_size) )
                    double_block = (col*block_size, row*block_size, )
                else: 
                    pygame.draw.rect(screen, (217, 241, 255), (double_block[0], double_block[1], block_size, block_size))
        
                    
                
    #Keyboard events
    
    for event in pygame.event.get(): 
            
        temp_puffle_x, temp_puffle_y = (puffle_x, puffle_y,)  
        
        if event.type == QUIT:
            running = False
            
        elif event.type == pygame.KEYDOWN:
            
            if event.key == pygame.K_ESCAPE:
                running = False
                
            elif event.key == pygame.K_LEFT:
                temp_puffle_x -= 32
                
            elif event.key == pygame.K_RIGHT:
                temp_puffle_x += 32
             
            elif event.key == pygame.K_UP:
                temp_puffle_y -= 32
          
            elif event.key == pygame.K_DOWN:
                temp_puffle_y += 32
                
            elif event.key == pygame.K_SPACE:
                game_over_check = False

        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                left_key = False
                
            elif event.key == pygame.K_RIGHT:
                right_key = False
                
            elif event.key == pygame.K_UP:
                up_key = False
                
            elif event.key == pygame.K_DOWN:
                down_key = False
                
        if (temp_puffle_x, temp_puffle_y, ) not in barriers and (temp_puffle_x, temp_puffle_y, ) not in used:
            if ((temp_puffle_x, temp_puffle_y, ) == locked_block and key) or (temp_puffle_x, temp_puffle_y, ) != locked_block:
                puffle_x, puffle_y = (temp_puffle_x, temp_puffle_y,)
            
            if (puffle_x, puffle_y, ) != double_block:
                points += 1
        
    
                
    #Game mechanics
    
    ##Move the puffle, Count points

    
    # if time_since_last_movement > 125:
    #     if left_key:
    #         temp_puffle_x -= 32
            
    #     if right_key:

            
    #     if up_key:
    #        temp_puffle_y -= 32
            
    #     if down_key:
    #         temp_puffle_y += 32
            
    #     time_since_last_movement = 0
    # else:
    #     time_since_last_movement += dt
        


    ##Game Over
    
    ###Check for Game Over
    adjacent_blocks = [(puffle_x + block_size, puffle_y, ), (puffle_x - block_size, puffle_y, ), (puffle_x, puffle_y + block_size, ), (puffle_x, puffle_y - block_size, )]

    if list(filter(lambda x: x in used or x in barriers, adjacent_blocks)) == adjacent_blocks:
        if (puffle_x, puffle_y) != final_block:
            game_over_check = True  

    ###Game Over screen
    if game_over_check:
        screen.fill((0, 0, 255))
        screen.blit(game_over, (250, 200))
        screen.blit(game_over_text, (50, 300))
        
        pygame.display.update()
        
        puffle_x = starting_positions[current_level][0]      
        puffle_y = starting_positions[current_level][1] 
        used = set()
        key = False
        first_pass = False
        
        continue
        
        
    ##Mark the blocks where the puffle has already been
    if (puffle_x, puffle_y, ) != double_block:
        used.add((puffle_x, puffle_y, ))

    ##Deal with different block types
    
    ###Final block
    if (puffle_x, puffle_y,) == final_block:
        
        #Check if the level was solved (100% blocks)
                
        if len(used) == spaces_num:
            solved += 1
        
        #Last level, end the game
        if current_level +1 > len(levels) - 1:
            running = False
        
        #Advance to the next level
        else:
            current_level += 1
            puffle_x = starting_positions[current_level][0]      
            puffle_y = starting_positions[current_level][1] 
            barriers = set()
            used = set()
            final_block = ()
            double_block = ()
            spaces_num = spaces_number()
            key = False
            first_pass = False

      
    ###Key block
    if (puffle_x, puffle_y,) == key_block:
        key = True
        
    ###Double block
    if previous_position != double_block and (puffle_x, puffle_y, ) == double_block:
        points += 1
        if not first_pass:
            first_pass = True
        else:
            used.add(double_block)  
            
    #Draw the puffle at final position, update screen
    screen.blit(puffle_img, (puffle_x, puffle_y) ) 
    pygame.display.update()

    
pygame.quit()